There are no Dependencies for the code.

The code can be built and run by running TestInferenceNetwork.