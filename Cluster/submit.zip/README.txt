Clustering can be built and run using eclipse by running ClusteringTest. It will generate the value for each threshold. 

This can be run with the base code provided in Moodle.