package Clustering;


public enum Linkage {
    SINGLE, COMPLETE, AVERAGE, MEAN
}
