package Clustering;


public interface SimilarityMethod {
     double similarity(DocumentVector rep1, DocumentVector rep2);
}